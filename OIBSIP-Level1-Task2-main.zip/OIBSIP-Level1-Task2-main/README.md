# OIBSIP-Level1-Task2

This is the Task-2 of Level-1 of the Oasis Infobyte Internship. Here In this task, Personal Portfolio Website is created using Tech-Stack HTML, CSS and JAVASCRIPT. This is just a one page website. The website is responsive for all the devices.

Technologies used to create this Personal Portfolio Website are :-
    
     ▪ HTML5
     ▪ CSS3
     ▪ Bootstrap
     ▪ JavaScript
